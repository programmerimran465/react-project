import React from 'react';
import './App.css';
import HomeSection1 from "./components/homeSection1";
import HomeSection2 from "./components/homeSection2";
import HomeSection3 from "./components/homeSection3";
import HomeSection4 from "./components/homeSection4";
import HomeSection5 from "./components/homeSection5";
import HomeSection6 from "./components/homeSection6";
import HomeSection7 from "./components/homeSection7";

function App() {
  return (
    <div className="App">

        <HomeSection1 />
        <HomeSection2 />
        <HomeSection3 />
        <HomeSection4 />
        <HomeSection5 />
        <HomeSection6 />
        <HomeSection7 />

    </div>
  );
}

export default App;
