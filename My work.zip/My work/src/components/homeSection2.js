import React, {Component, Fragment} from 'react';
import '../assets/css/style.css';
import '../assets/css/bootstrap.min.css';
import '../assets/css/fontawesome-all.css';
import {Container, Row} from "react-bootstrap";
import bg from '../assets/img/bg.jpg';

class HomeSection2 extends Component {
    render() {
        return (
            <Fragment>
                <Container>
                    <Row>
                      <div className="wrapper">
                        <div className="steps-area steps-area-fixed">
                          <div className="image-holder">
                            <img src={bg.jpg} alt="bg" />
                             </div>
                               <div className="steps clearfix">
                                  <ul className="tablist multisteps-form__progress">
                                    <li className="multisteps-form__progress-btn js-active current">
                                    <span>1</span>
                                    </li>
                                    <li className="multisteps-form__progress-btn">
                                    <span>2</span>
                                    </li>
                                    <li className="multisteps-form__progress-btn">
                                    <span>3</span>
                                    </li>
                                    <li className="multisteps-form__progress-btn">
                                    <span>4</span>
                                    </li>
                                    <li className="multisteps-form__progress-btn last">
                                    <span>5</span>
                                    </li>
                                  </ul>
                               </div>
                            </div>
                          </div>
                     </Row>
                </Container>
            </Fragment>
        );
    }
}

export default HomeSection2;