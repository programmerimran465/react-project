import React, {Component, Fragment} from 'react';
import '../assets/css/style.css';
import '../assets/css/animate.min.css';
import '../assets/css/fontawesome-all.css';
import {Container, Row} from "react-bootstrap";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'

class HomeSection1 extends Component {
    render() {
        return (
            <Fragment>
                <Container>
                    <Row>
                       <div id="switch-color" className="color-switcher">
                          <div className="open"><i className="fas fa-cog"></i></div>
                             <h4>COLOR OPTION</h4>
                               <ul>
                                  <li><a className="color-2" onClick="setActiveStyleSheet('color-2'); return false;" href="#"><i className="fas fa-cog"></i></a></li>
                                  <li><a className="color-3" onClick="setActiveStyleSheet('color-3'); return false;" href="#"><i className="fas fa-cog"></i></a></li>
                                  <li><a className="color-4" onClick="setActiveStyleSheet('color-4'); return false;" href="#"><i className="fas fa-cog"></i></a></li>
                                 <li><a className="color-5" onClick="setActiveStyleSheet('color-5'); return false;" href="#"><i className="fas fa-cog"></i></a></li>
                               </ul>
                         </div>
                    <div className="clearfix"></div>
                    </Row>
                </Container>
            </Fragment>
        );
    }
}

export default HomeSection1;