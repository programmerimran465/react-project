import React, {Component, Fragment} from 'react';
import '../assets/css/style.css';
import '../assets/css/bootstrap.min.css';
import '../assets/css/fontawesome-all.css';
import {Col, Row, Container} from "react-bootstrap";
import d1 from '../assets/img/d1.png';
import d2 from '../assets/img/d2.png';
import d3 from '../assets/img/d3.png';

class HomeSection3 extends Component {
    render() {
        return (
            <Fragment>
                <Container>
                    <Row>
                      <form className="multisteps-form__form" action="#" id="wizard" method="POST">
                         <div className="form-area position-relative">
                           <div className="multisteps-form__panel js-active" data-animation="slideHorz">
                             <div className="wizard-forms">
                                <div className="inner pb-100 clearfix">
                                    <div className="form-content pera-content">
                                        <div className="step-inner-content">
                                            <span className="step-no">Step 1</span>
                                            <h2>What kind of Services You need?</h2>
                                            <p>Tation argumentum et usu, dicit viderer evertitur te has. Eu dictas concludaturque usu, facete detracto patrioque an per, lucilius pertinacia eu vel.</p>
                                            <div className="step-box">
                                                <div className="Row">
                                                    <Col md={4}>
                                                        <label className="step-box-content bg-white text-center relative-position active">
													        <span className="step-box-icon">
														     <img src={d1.png} alt="d1" />
														    </span>
                                                            <span className="step-box-text">Corporate Services</span>
                                                            <span className="service-check-option">
														      <span><input type="radio" name="service_name" value="Corporate Services" checked /></span>
													        </span>
                                                        </label>
                                                    </Col>
                                                    <Col md={4}>
                                                        <label className="step-box-content bg-white text-center relative-position">
													        <span className="step-box-icon">
                                                              <img src={d2.png} alt="d2" />
													        </span>
                                                              <span className="step-box-text">Freelancing Services</span>
                                                            <span className="service-check-option">
														       <span><input type="radio" name="service_name" value="Freelancing Services" /></span>
													        </span>
                                                        </label>
                                                    </Col>
                                                    <Col md={4}>
                                                        <label className="step-box-content bg-white text-center relative-position">
													      <span className="step-box-icon">
														   <img src={d3.png} alt="d3" />
													      </span>
                                                           <span className="step-box-text">Development</span>
                                                            <span className="service-check-option">
														     <span><input type="radio" name="service_name" value="Development Services" /></span>
													       </span>
                                                        </label>
                                                    </Col>
                                                  </div>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                                <div className="actions">
                                    <ul>
                                        <li className="disable" aria-disabled="true"><span className="js-btn-next" title="NEXT">Backward <i className="fa fa-arrow-right"></i></span></li>
                                        <li><span className="js-btn-next" title="NEXT">NEXT <i className="fa fa-arrow-right"></i></span></li>
                                    </ul>
                                  </div>
                               </div>
                            </div>
                          </div>
                       </form>
                    </Row>
                </Container>
            </Fragment>
        );
    }
}

export default HomeSection3;