import React, {Component, Fragment} from 'react';
import '../assets/css/style.css';
import '../assets/css/bootstrap.min.css';
import '../assets/css/fontawesome-all.css';
import {Container, Row} from "react-bootstrap";

class HomeSection7 extends Component {
    render() {
        return (
            <Fragment>
                <Container>
                   <Row>
                     <form className="multisteps-form__form" action="#" id="wizard" method="POST">
                       <div class="multisteps-form__panel" data-animation="slideHorz">
                         <div class="wizard-forms">
                           <div class="inner pb-100 clearfix">
                            <div class="form-content pera-content">
                                <div class="step-inner-content">
                                    <span class="step-no bottom-line">Step 5</span>
                                    <div class="step-progress float-right">
                                        <span>5 of 5 completed</span>
                                        <div class="step-progress-bar">
                                            <div class="progress">
                                                <div class="progress-bar" style={{width:"100%"}}></div>
                                            </div>
                                        </div>
                                    </div>
                                    <h2>Complete Final Step</h2>
                                    <p>Tation argumentum et usu, dicit viderer evertitur te has. Eu dictas concludaturque usu, facete detracto patrioque an per, lucilius pertinacia eu vel.</p>
                                    <div class="step-content-field">
                                        <div class="date-picker date datepicker">
                                            <input type="text" name="date" class="form-control" />
                                                <div class="input-group-append" /><span>ADD TIME</span></div>
                                        </div>
                                        <div class="plan-area">
                                            <div class="plan-icon-text text-center active">
                                                <div class="plan-icon">
                                                    <i class="fas fa-chess-queen"></i>
                                                </div>
                                                <div class="plan-text">
                                                    <h3>Unlimited Plan</h3>
                                                    <p>Tation argumentum et usu, dicit viderer evertitur te has. Eu dictas concludaturque usu, dicit viderer evertitur</p>
                                                    <input type="radio" name="your_plan" value="Unlimited Plan" checked="" />
                                                </div>
                                            </div>
                                            <div class="plan-icon-text text-center">
                                                <div class="plan-icon">
                                                    <i class="fas fa-cubes"></i>
                                                </div>
                                                <div class="plan-text">
                                                    <h3>Limited Plan</h3>
                                                    <p>Tation argumentum et usu, dicit viderer evertitur te has. Eu dictas concludaturque usu, dicit viderer evertitur</p>
                                                    <input type="radio" name="your_plan" value="Unlimited Plan" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="budget-area">
                                            <p>Optimization and Accessibility</p>
                                            <div class="opti-list">
                                                <ul class="d-flex">
                                                    <li class="bg-white active"><input type="checkbox" name="code_opti1" value="Semantic coding" checked />Semantic coding</li>
                                                    <li class="bg-white"><input type="checkbox" name="code_opti2" value="Mobile APP" />Mobile APP</li>
                                                    <li class="bg-white"><input type="checkbox" name="code_opti3" value="Mobile Design" />Mobile Design</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="comment-box">
                                            <textarea name="extra-message" placeholder="Some Note"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                           <div class="actions">
                              <ul>
                                <li><span class="js-btn-prev" title="BACK"><i class="fa fa-arrow-left"></i> BACK </span></li>
                                <li><button type="submit" title="NEXT">SUBMIT <i class="fa fa-arrow-right"></i></button></li>
                              </ul>
                           </div>
                       </div>
                    </form>
                 </Row>
               </Container>
            </Fragment>
        );
    }
}

export default HomeSection7;